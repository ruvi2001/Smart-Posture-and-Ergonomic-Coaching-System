let trendChart = null;
let breakdownChart = null;
let liveTrendChart = null;

async function loadLiveDashboard() {
  try {
    const latestRes = await fetch("/api/live/latest");
    const latestJson = await latestRes.json();

    if (!latestJson.success || !latestJson.data) {
      console.warn("No latest live reading found");
      return;
    }

    const latest = latestJson.data;

    document.getElementById("avgScore").textContent =
      latest.posture_score !== null ? `${latest.posture_score}/100` : "--";

    document.getElementById("dominantPosture").textContent =
      formatPostureLabel(latest.posture_status);

    document.getElementById("avgDistance").textContent =
      `${Number(latest.distance_cm).toFixed(1)} cm`;

    document.getElementById("avgTilt").textContent =
      `${Number(latest.accel_deviation || 0).toFixed(2)}`;

    document.getElementById("balanceStatus").textContent =
      getBalanceText(latest.seat_balance_lr, latest.seat_balance_fb);

    updateAlertBanner(latest);

    await loadLiveTrend();

  } catch (error) {
    console.error("Live dashboard error:", error);
  }
}

async function loadLiveTrend() {
  const res = await fetch("/api/live/history?limit=50");
  const json = await res.json();

  if (!json.success || !json.data) return;

  const rows = json.data.reverse();

  const labels = rows.map(r => {
    const d = new Date(r.recorded_at_utc);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  });

  const values = rows.map(r => r.posture_score || 0);

  renderTrendChart(labels, values);
}

function updateAlertBanner(reading) {
  const title = document.getElementById("alertTitle");
  const msg = document.getElementById("alertMessage");

  if (!title || !msg) return;

  if (reading.posture_status === "bad_posture") {
    title.textContent = `${formatPostureLabel(reading.bad_posture_type)} detected`;
    msg.textContent = reading.posture_reason || "Poor posture detected. Please correct your sitting position.";
  } else if (reading.posture_status === "good_posture") {
    title.textContent = "Good posture detected";
    msg.textContent = "Your current posture is stable. Keep maintaining this position.";
  } else {
    title.textContent = "Chair not occupied";
    msg.textContent = "No active sitting posture detected.";
  }
}

function getBalanceText(lr, fb) {
  lr = Number(lr || 0);
  fb = Number(fb || 0);

  if (Math.abs(lr) < 0.08 && Math.abs(fb) < 0.08) return "Centered";
  if (fb < -0.08) return "Backward Lean";
  if (fb > 0.08) return "Forward Lean";
  if (lr < -0.08) return "Left Lean";
  if (lr > 0.08) return "Right Lean";

  return "Slight Imbalance";
}

document.addEventListener("DOMContentLoaded", () => {
  loadLiveDashboard();
  setInterval(loadLiveDashboard, 3000);
});

async function loadDashboardData() {
  const range = document.getElementById("dateRangeFilter").value;
  const postureClass = document.getElementById("postureClassFilter").value;
  const session = document.getElementById("sessionFilter").value;

  const url = `/api/dashboard-data?range=${range}&posture_class=${postureClass}&session=${session}`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    updateMetricCards(data);
    populateSessions(data.sessions || []);
    renderBreakdownChart(data.posture_distribution || {});
    renderTrendChart(data.trend_labels || [], data.trend_values || []);
    renderHeatmap(data.heatmap || []);
    updateDecisionSupport(data);
    loadRecentReadings();

  } catch (error) {
    console.error("Dashboard loading error:", error);
  }
}

function updateMetricCards(data) {
  document.getElementById("avgScore").textContent = `${data.avg_score ?? 0}/100`;
  document.getElementById("totalAlerts").textContent = data.total_alerts ?? 0;
  document.getElementById("goodPosturePct").textContent = `${data.good_posture_pct ?? 0}%`;
  document.getElementById("avgDistance").textContent = `${data.avg_distance ?? 0} cm`;

  const distribution = data.posture_distribution || {};

  const good = distribution.good || 0;
  const neutral = distribution.neutral || 0;
  const poor = distribution.bad || 0;

  document.getElementById("goodCount").textContent = good;
  document.getElementById("neutralCount").textContent = neutral;
  document.getElementById("poorCount").textContent = poor;

  const dominant = getDominantPosture(distribution);
  document.getElementById("dominantPosture").textContent = formatPostureLabel(dominant);

  document.getElementById("avgTilt").textContent = data.avg_tilt_x !== undefined
    ? `${data.avg_tilt_x}°`
    : "--";

  document.getElementById("balanceStatus").textContent = data.balance_status || "Centered";
}

function populateSessions(sessions) {
  const sessionFilter = document.getElementById("sessionFilter");
  const currentValue = sessionFilter.value;

  sessionFilter.innerHTML = `<option value="all">All</option>`;

  sessions.forEach(session => {
    const option = document.createElement("option");
    option.value = session;
    option.textContent = session;
    sessionFilter.appendChild(option);
  });

  if ([...sessionFilter.options].some(option => option.value === currentValue)) {
    sessionFilter.value = currentValue;
  } else {
    sessionFilter.value = "all";
  }
}

function renderBreakdownChart(distribution) {
  const good = distribution.good || 0;
  const neutral = distribution.neutral || 0;
  const poor = distribution.bad || 0;

  const ctx = document.getElementById("breakdownChart");

  if (breakdownChart) {
    breakdownChart.destroy();
  }

  breakdownChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Good", "Neutral", "Poor"],
      datasets: [{
        data: [good, neutral, poor],
        backgroundColor: ["#16a34a", "#e68a00", "#ef4444"],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          display: false
        }
      },
      cutout: "68%"
    }
  });
}

function renderTrendChart(labels, values) {
  const ctx = document.getElementById("trendChart");

  if (trendChart) {
    trendChart.destroy();
  }

  trendChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: labels,
      datasets: [{
        label: "Average Posture Score",
        data: values,
        tension: 0.35,
        fill: true,
        borderColor: "#2563eb",
        backgroundColor: "rgba(37,99,235,.12)"
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          min: 0,
          max: 100
        }
      },
      onClick: async function (event, elements) {
        if (elements.length > 0) {
          const index = elements[0].index;
          const selectedDate = labels[index];
          await loadDrilldown(selectedDate, null);
        }
      }
    }
  });
}

function renderHeatmap(heatmapData) {
  const heat = document.getElementById("heatmap");
  if (!heat) return;

  heat.innerHTML = "";

  if (!heatmapData || heatmapData.length === 0) {
    heat.innerHTML = "<p class='muted-text'>No heatmap data available.</p>";
    return;
  }

  heatmapData.slice(0, 30).forEach(item => {
    const cell = document.createElement("div");

    const score = item.posture_score || item.score || 0;

    cell.className = "heat-cell " + (
      score >= 75 ? "good" :
      score >= 55 ? "mod" :
      "poor"
    );

    cell.title = `${item.day || item.date || "Day"} ${item.hour ?? ""}:00 score ${score}`;

    cell.onclick = async () => {
      const date = item.date || item.day;
      const hour = item.hour;
      await loadDrilldown(date, hour);
    };

    heat.appendChild(cell);
  });
}

async function loadDrilldown(date, hour) {
  let url = `/api/drilldown?date=${encodeURIComponent(date)}`;

  if (hour !== null && hour !== undefined) {
    url += `&hour=${encodeURIComponent(hour)}`;
  }

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.error) return;

    document.getElementById("alertTitle").textContent = `Selected: ${data.title}`;
    document.getElementById("alertMessage").textContent =
      `Average score: ${data.avg_score}/100 | Alerts: ${data.alerts} | Dominant posture: ${formatPostureLabel(data.dominant_class)} | Recommendation: ${data.recommendation}`;

  } catch (error) {
    console.error("Drilldown error:", error);
  }
}

async function loadRecentReadings() {
  try {
    const response = await fetch("/api/recent-readings");
    const rows = await response.json();

    const tbody = document.getElementById("recentReadingsBody");
    tbody.innerHTML = "";

    if (!rows || rows.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7">No recent readings found.</td></tr>`;
      return;
    }

    rows.forEach(row => {
      const tr = document.createElement("tr");

      tr.innerHTML = `
        <td>${row.time}</td>
        <td>${row.score}</td>
        <td>${formatPostureLabel(row.class)}</td>
        <td>${row.distance} cm</td>
        <td>${row.balance}</td>
        <td>${row.alert ? "Yes" : "No"}</td>
        <td>${row.exercise}</td>
      `;

      tbody.appendChild(tr);
    });

  } catch (error) {
    console.error("Recent readings error:", error);
  }
}

function updateDecisionSupport(data) {
  const avgScore = data.avg_score || 0;
  const alerts = data.total_alerts || 0;
  const avgDistance = data.avg_distance || 0;

  let risk = "Low Risk";
  let reason = "Your posture pattern looks stable. Continue monitoring and maintain regular breaks.";

  if (avgScore < 70 || alerts > 10) {
    risk = "High Risk";
    reason = "Your posture score or alert count indicates a high risk pattern. Prioritize posture correction and short exercise breaks.";
  } else if (avgScore < 80 || alerts > 5) {
    risk = "Medium Risk";
    reason = "Your posture is acceptable but needs improvement. Focus on screen distance, back support, and regular movement.";
  }

  if (avgDistance > 0 && avgDistance < 45) {
    reason += " Your screen distance is also too close, which may increase neck strain.";
  }

  document.getElementById("riskLevel").textContent = risk;
  document.getElementById("riskReason").textContent = reason;
}

function getDominantPosture(distribution) {
  const entries = Object.entries(distribution);

  if (entries.length === 0) return "--";

  entries.sort((a, b) => b[1] - a[1]);
  return entries[0][0];
}

function formatPostureLabel(value) {
  if (!value || value === "--") return "--";

  return value
    .replaceAll("_", " ")
    .replace(/\b\w/g, char => char.toUpperCase());
}

function askChartAI(question) {
  if (typeof openFloatingChatbot === "function") {
    openFloatingChatbot();
  }

  const input =
    document.getElementById("floatingChatInput") ||
    document.getElementById("chatInput") ||
    document.querySelector("input[name='message']");

  if (!input) {
    alert("Chatbot input not found. Check floating chatbot input ID.");
    return;
  }

  input.value = question;

  if (typeof sendFloatingMessage === "function") {
    sendFloatingMessage();
  } else if (typeof sendMessage === "function") {
    sendMessage();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadDashboardData();
  loadLiveDashboard();
  setInterval(loadLiveDashboard, 3000);
});